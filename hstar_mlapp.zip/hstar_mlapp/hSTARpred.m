function [yhRespF,yhTreatF,yhRespProb,yhTreatProb] = hSTARpred(data)
% Predicts optimal speech therapy for individual with post-stroke aphasia
% based on a series of multimodal features contained in the input 'data'
% (345 x 1). See example.xlsx for which specific feature each index
% corresponds to. See hSTARprepro.m for how to process neuroimaging
% features to use in the 'data' input.
%
% Outputs: ---------------------------------------------------------------
% yhRespF: the consensus vote for whether the individual will
% respond to treatment. 0 means they will not, 1 means they will.
%
% yhTreatF: the consensus vote for which treatment the individual would
% respond to. This should only be used if yhRespF is 1 but we provide it
% anyways in case treatment must be assigned. 1 means the individual will
% respond to semantic treatment, 2 means they will respond to phonological
% treatment
%
% yhRespProb: proportion of 92 models that predicted the individual will
% respond to treatment
%
% yhTreatProb: proportion of 39 models that predicted the individual will
% respond to phonological treatment

load('hSTAR.mat')
for j = 1:length(responderModel)
    teX1 = data(responderFeatures{j});

    [~,yhPR] = predict(responderModel{j},teX1);
    plattScale = @(score) 1 ./ (1 + exp(-responderPlatta(j) * score - responderPlattb(j)));
    yhPR = plattScale(yhPR(:, 2));
    yhPR = [1 - yhPR, yhPR];

    if yhPR(2) >= responderThreshold(j)
        yhResp(j,1) = true; % responder
    else
        yhResp(j,1) = false; % non-responder
    end
end
yhRespF = mode(yhResp);
yhRespProb = mean(yhResp);

for j = 1:length(treatmentModel)
    teX2 = data(treatmentFeatures{j});

    [~,yhPT] = predict(treatmentModel{j},teX2);
    plattScale = @(score) 1 ./ (1 + exp(-treatmentPlatta(j) * score - treatmentPlattb(j)));
    yhPT = plattScale(yhPT(:, 2));
    yhPT = [1 - yhPT, yhPT];

    if yhPT(2) >= responderThreshold(j)
        yhTreat(j,1) = 1; % semantic
    else
        yhTreat(j,1) = 2; % phonological
    end
end
yhTreatF = mode(yhTreat);
yhTreatProb = mean(yhTreat-1);
